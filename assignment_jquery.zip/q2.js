// Q2 - Product Highlight
$(function(){
  // Click to highlight product
  $("#products").on("click", ".product", function(){
    $(".product").removeClass("highlight");
    $(this).addClass("highlight");
    // If out of stock -> alert (using data attribute)
    if($(this).data("stock")==="out"){
      alert("This product is out of stock!");
    }
  });
  // Hover show additional details (simple demo via title attribute)
  $("#products").on("mouseenter", ".product", function(){
    const disc = $(this).data("discount");
    $(this).append(" <small>(Discount: "+disc+"%)</small>");
  }).on("mouseleave", ".product", function(){
    $(this).find("small").remove();
  });
  // Favorite toggle
  $("#products").on("click", ".fav", function(e){
    e.stopPropagation();
    $(this).toggleClass("selected");
    $(this).text($(this).hasClass("selected") ? "★" : "☆");
  });
  // Apply style to discounted products using attribute selector
  $("[data-discount]").each(function(){
    if($(this).data("discount")>0){
      $(this).css("font-weight","700");
    }
  });
});
