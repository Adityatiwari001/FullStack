// Q6 - Event Subscription Panel
$(function(){
  function showMessage(msg){
    $("<div class='msg'>"+msg+"</div>").appendTo("body").fadeOut(2000,function(){ $(this).remove(); });
  }
  $("#subscribe").click(function(){
    $(".topic:checked").each(function(){
      $(this).closest("label").css("font-weight","700");
    });
    showMessage("Subscribed to selected topics");
  });
  $("#unsubscribe").click(function(){
    $(".topic:checked").each(function(){
      $(this).prop("checked",false).closest("label").css("font-weight","400");
    });
    showMessage("Unsubscribed");
  });
  // Dynamically add new subscription topic and attach .on() handler
  $("#addTopic").click(function(){
    const html = '<label><input type="checkbox" class="topic" value="newTopic"> NewTopic</label><br>';
    $("#topics").append(html);
    showMessage("New topic added");
  });
  // Remove specific subscription: demonstrate detach/off by creating a remove button on dynamic topics
  $(document).on("contextmenu", ".topic", function(e){
    e.preventDefault();
    $(this).closest("label").remove();
    showMessage("Topic removed");
  });
});
