// Q10 - Registration Form Validation
$(function(){
  const existing = ["taken@example.com","user@domain.com"];
  $("#reg").submit(function(e){
    e.preventDefault();
    let valid = true;
    const name = $("#name").val().trim();
    const email = $("#email").val().trim();
    const pw = $("#password").val();
    $("#result").empty();
    if(!name){ $("#name").css("border","2px solid red"); valid=false; } else { $("#name").css("border",""); }
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!emailRe.test(email) || existing.includes(email)){ $("#email").css("border","2px solid red"); $("#result").append("<div>Invalid or taken email</div>"); valid=false; } else { $("#email").css("border",""); }
    if(pw.length < 8){ $("#password").css("border","2px solid red"); valid=false; } else { $("#password").css("border",""); }
    if(valid){ $("#result").text("Registration successful!").css("color","green"); }
  });
});
