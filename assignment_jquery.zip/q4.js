// Q4 - Special Offer Banner
$(function(){
  $("#hide").click(()=>$(".banner").hide());
  $("#show").click(()=>$(".banner").show());
  $("#slide").click(()=>$(".banner").slideToggle());
  $("#fade").click(()=>$(".banner").fadeToggle());
  // 5. Rotate banners every 5 seconds via fadeIn/fadeOut
  let idx = 0;
  const banners = $(".banner");
  banners.hide();
  function rotate(){
    banners.eq(idx).fadeIn(600).delay(1400).fadeOut(600, function(){
      idx = (idx+1)%banners.length;
      setTimeout(rotate, 200);
    });
  }
  rotate();
});
