// Q3 - Interactive FAQ
$(function(){
  $(".answer").hide();
  // 1. Click question -> toggle its answer
  $(".question").click(function(){
    $(this).next(".answer").slideToggle();
  });
  // 2. Hover -> change color
  $(".question").hover(function(){
    $(this).css("color","blue");
  }, function(){
    $(this).css("color","");
  });
  // 3. Double-click -> collapse all answers
  $(".question").dblclick(function(){
    $(".answer").slideUp();
  });
  // 4/5 Focus/blur example: create an input for editing an answer
  $(".qa").append('<input class="editAnswer" placeholder="Edit answer..." />');
  $(".editAnswer").focus(function(){
    $(this).closest(".qa").css("background","#eef");
  }).blur(function(){
    $(this).closest(".qa").css("background","");
  });
});
