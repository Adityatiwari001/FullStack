// Q9 - Multi-JQuery Widgets
// Demonstration: using noConflict would be used when multiple versions are loaded.
// Here we simply show widget highlight behavior.
$(function(){
  $(".widget").first().addClass("active");
  // Tooltips on hover (simple title)
  $(".widget").hover(function(){
    $(this).attr("title","Tooltip for " + $(this).text());
  });
  // Active highlight
  $(".widget").click(function(){
    $(".widget").removeClass("active");
    $(this).addClass("active");
  });
});
