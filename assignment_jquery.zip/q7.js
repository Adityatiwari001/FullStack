// Q7 - Search Courses
$(function(){
  function updateCount(n){ $("#count").text(n); }
  $("#search").on("keyup", function(){
    const q = $(this).val().toLowerCase();
    let matched = 0;
    $(".course").each(function(){
      const txt = $(this).text().toLowerCase();
      if(q && txt.indexOf(q)>=0){
        $(this).show();
        // highlight matched text using .css()
        $(this).css("font-weight","700");
        matched++;
      } else if(q){
        $(this).hide();
      } else {
        $(this).show().css("font-weight","");
      }
    });
    updateCount(matched);
  });
  $("#clear").click(function(){
    $("#search").val("").keyup();
  });
});
