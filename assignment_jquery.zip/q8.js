// Q8 - Dynamic Blog Posts
$(function(){
  $("#add").click(function(){
    $("#posts").append('<div class="post">New Post</div>');
  });
  $("#prepend").click(function(){
    $("#posts").prepend('<div class="post featured">Featured Post</div>');
  });
  $("#removeLast").click(function(){
    $("#posts .post").last().remove();
  });
  // Add tags using before/after
  $(document).on("mouseenter", ".post", function(){
    if(!$(this).find(".tag").length){
      $(this).append('<span class="tag"> [tagged]</span>');
    }
  });
  // Highlight posts with keyword 'Featured'
  $("#posts").find(".post:contains('Featured')").css("background","#ffd");
});
