// Q1 - Welcome Page Greeting
// On load: set greeting by time of day.
$(function(){
  function setGreeting(){
    const hour = new Date().getHours();
    let text = "Good Evening";
    if(hour < 12) text = "Good Morning";
    else if(hour < 18) text = "Good Afternoon";
    $("#greeting").text(text + " — welcome to the site!");
  }
  setGreeting();
  // Change to motivational quote
  $("#changeGreeting").click(function(){
    $("#greeting").text("Keep going — small steps every day!");
  });
  // Toggle visibility
  $("#toggleWelcome").click(function(){
    $("#welcomeMsg").toggle();
  });
  // Show alert when greeting clicked
  $("#greeting").click(function(){
    alert("Greeting clicked!");
  });
});
