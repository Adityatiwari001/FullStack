// Q5 - Team Members Directory
$(function(){
  $(".contact").hide();
  // Click manager -> highlight direct reports
  $(".dept h3").click(function(){
    $(this).siblings("ul").find(".employee").css("background","#ffd");
  });
  // Hover on employee -> show contact using .next() (contact is inside same li so use find)
  $(".employee").hover(function(){
    $(this).find(".contact").show();
  }, function(){
    $(this).find(".contact").hide();
  });
  // Click department -> change background of all members using .children()
  $(".dept").click(function(){
    $(this).children("ul").children(".employee").css("border","1px solid #ccc");
  });
  // Random employee -> highlight siblings
  $("#random").click(function(){
    const all = $(".employee");
    const picked = all.eq(Math.floor(Math.random()*all.length));
    picked.siblings().css("opacity",0.6);
  });
  // Collapse/expand team using parent() and find()
  $("#collapse").click(function(){
    $(".dept").find("ul").slideToggle();
  });
});
